# projetoJSF
* Sistema de salão de beleza, feito com JSF, Java, Hibernate.
* Criando com Maven no Eclipse

Link de como subir um projeto Maven: https://imasters.com.br/back-end/criando-projeto-jsf-com-maven-eclipse
